Proyecto Juego de memoria:

En este proyecto se ha creado un juego de memoria, que consiste en preguntar al usuario el tamaño que quiere 
que tenga el tablero que va usar, el número de filas y de columnas. Después el programa imprimirá un tablero
con la cantidad de casillas indicadas por el usuario y dentro de ellas apareceran 10 iconos con sus 
respectivas parejas colocadas de forma aleatoria.


Indicaciones:
    -El número total de casillas debe ser un número par si no es así se volvera a preguntar hasta que se 
    introduzca un número par.