Proyecto Juego de memoria:

En este proyecto se ha creado un juego de memoria, que consiste en preguntar al usuario el tamaño que quiere 
que tenga el tablero que va usar, el número de filas y de columnas. Después el programa imprimirá un tablero
con la cantidad de casillas indicadas por el usuario y dentro de ellas apareceran 10 iconos con sus 
respectivas parejas colocadas de forma aleatoria.


Instrucciones del juego:
	
	-Se preguntará al usuario el número de filas y columnas con las que quiere jugar.
	-El número total de estas debe ser par, si no es así se volvera a preguntar hasta que se 
	introduzca un número par.
	-El usuario girará dos casillas cada vez.
	-Si las dos casillas son iguales se habrá conseguido una pareja correcta y se sumará a los
	puntos.
	-Si por el contrario son distintas, se girarán esas dos casillas y se deberán elegir otras
	dos.
	-La finalidad es recordar en que casilla estaba cada icono para así poder conseguir todas
	las parejas.
	-El juego finaliza cuando se ha conseguido seleccionar todas las parejas correctamente.
	-El juego también cuenta con un botón para recargar el tablero si se desea volver a 
	empezar de nuevo la partida.

Navegadores utilizados para las comprobaciones:
	
	-Google chrome.
	-Microsoft edge.
	